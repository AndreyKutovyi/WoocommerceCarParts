<?php

$recepient = "ruslancom.ua@gmail.com";
$sitename = "cloudtaxi";

$name = trim($_GET["f_name"]);
$phone = trim($_GET["f_phone"]);
$mail = trim($_GET["f_mail"]);
$place = trim($_GET["f_country"]);
$text = trim($_GET["f_comment"]);

$pagetitle = "Письмо с сайта \"$sitename\"";
$message = "Имя: $name \nТелефон: $phone \nПочта: $mail \nСтрана: $place \nКраткое описание: \n$text";
mail($recepient, $pagetitle, $message, "Content-type: text/plain; charset=\"utf-8\"\n From: info@oel.com.ua");